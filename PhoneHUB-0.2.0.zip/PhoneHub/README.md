# PhoneHUB

Aplicativo desktop para conectar um Android, espelhar a tela, ajustar vídeo/áudio e abrir uma pré-visualização da câmera. A interface usa **Python + PySide6/Qt** (Qt é uma camada nativa escrita principalmente em C++); o trabalho pesado de espelhamento é feito pelo **scrcpy**, com **ADB** para comunicação Android. Não foi adicionado C++ artificialmente ao projeto: a arquitetura já usa componentes nativos onde isso faz sentido.

> **Estado real:** este é um projeto em desenvolvimento. A interface e os fluxos básicos estão implementados, mas o vídeo abre numa janela separada do scrcpy. Não há ainda mapeamento universal de teclas para toques, webcam virtual pronta para todos os sistemas, nem espelhamento/controle completo de iPhone sem app. O README não promete esses recursos como concluídos.

## Recursos atuais

- Interface escura redesenhada, navegação lateral, cartões de status e telas dedicadas.
- Descoberta de Android por USB ou ADB já conectado por Wi-Fi; conexão manual `IP:porta`.
- Ajuste de resolução, bitrate e FPS do scrcpy.
- Preferência experimental de renderização (automática, OpenGL/GPU ou compatibilidade/CPU). A escolha é best-effort e não força hardware que não existe.
- Opções para encaminhamento de áudio e microfone, conforme o suporte do Android/scrcpy.
- Pré-visualização de câmera Android com lente, resolução e FPS configuráveis.
- Identificação básica de iPhone/iPad via `libimobiledevice` quando o sistema e a confiança USB permitem.
- Preferências persistidas em arquivo de configuração do usuário.
- Seletor inicial: abrir a interface ou executar diagnóstico no terminal.
- Scripts para desenvolvimento Linux e empacotamento Windows.

## Compatibilidade

### Android

A versão de Android e os recursos disponíveis dependem da versão instalada do scrcpy. ADB precisa estar autorizado no telefone. Para USB, ative Opções do desenvolvedor e Depuração USB e aceite a chave do computador. Para rede, configure a depuração sem fio no Android; dependendo da versão, use o fluxo de pareamento do próprio ADB antes de conectar.

**Android 12 ou inferior:** espelhamento básico tende a funcionar com versões compatíveis de scrcpy/ADB, mas câmera, áudio e opções específicas variam por versão. A aplicação não consegue garantir que todo recurso funcione em todos os modelos.

### Jogos / Roblox

PhoneHUB inicia scrcpy, que encaminha teclado e mouse. Roblox para Android só aceitará essas entradas nas experiências/versões que suportem teclado e mouse externos. O projeto ainda **não** implementa conversão configurável de cada tecla em coordenadas de toque, então não promete controle universal de jogos touchscreen nem execução da versão de PC do Roblox no celular.

### iPhone / iPad

A integração atual usa `idevice_id` e `ideviceinfo` para detecção e informações acessíveis. iOS não possui ADB equivalente nem permite, de forma geral, espelhamento e controle remoto completos sem app/fluxos especiais. O suporte atual é de identificação, não controle total.

## Instalação no CachyOS / Arch Linux

Dependências nativas:

```fish
sudo pacman -S --needed python python-pip android-tools scrcpy libimobiledevice usbmuxd ffmpeg
```

Crie e use o ambiente virtual **sem ativação**, para funcionar no Fish e evitar conflito com o Python gerenciado pelo sistema:

```fish
cd ~/Downloads/PhoneHub
python -m venv .venv
./.venv/bin/python -m pip install --upgrade pip
./.venv/bin/python -m pip install -e .
./.venv/bin/python main.py
```

O seletor inicial oferece **Abrir aplicativo** ou **Rodar pelo terminal**. Para abrir diretamente sem o seletor: `./.venv/bin/python main.py --skip-launcher`. Para diagnóstico: `./.venv/bin/python main.py --terminal`.

## Configuração e desempenho

- Use USB de dados de boa qualidade para menor latência.
- Comece em 1280, 8M e 60 FPS; se houver engasgos, teste 960/4M/30 FPS.
- O desempenho depende do encoder do telefone, conexão, decodificador e GPU/driver do computador.
- A opção de renderização é uma preferência best-effort; a aplicação não pode escolher qualquer GPU em todos os sistemas, e `LIBGL_ALWAYS_SOFTWARE` pode piorar o desempenho.
- Configuração: `~/.config/phonehub/config.json` no Linux ou `%APPDATA%\PhoneHUB\config.json` no Windows.

## Windows: gerar PhoneHUB.exe

O executável principal é empacotado com PyInstaller. Isso inclui Python e bibliotecas Python dentro do executável; o usuário não precisa instalar Python para executar o app empacotado. **ADB e scrcpy ainda precisam ser distribuídos junto ou instalados separadamente**; o build não finge que essas ferramentas estão incluídas.

Em um Windows com Python instalado, abra CMD na pasta do projeto:

```bat
scripts\build-windows.bat
```

Saídas esperadas em `dist\PhoneHUB.exe` e `dist\PhoneHUB-console.exe`. O segundo é útil para diagnóstico pelo CMD. O build pode ser feito no Windows; não gere um `.exe` Windows a partir do Linux.

### Criar `setup.exe`

O bootstrapper em `installer/setup_bootstrapper.py` pode ser compilado como `setup.exe`. Ele baixa `PhoneHUB.exe` de uma URL de lançamento que **você controla** e salva em `%LOCALAPPDATA%\Programs\PhoneHUB`. Não existe URL de download embutida porque o projeto ainda não tem servidor/release público.

1. Gere `dist\PhoneHUB.exe` no Windows.
2. Publique o executável em um HTTPS de sua propriedade (por exemplo, a página de Releases do repositório).
3. Edite `installer\release_url.txt` com a URL direta do arquivo `PhoneHUB.exe`.
4. Execute `scripts\build-setup.bat` no CMD; o script compila o bootstrapper em `dist\setup.exe`.
5. Ao distribuir, mantenha a URL válida e hospede apenas builds que você verificou.

O setup não instala Python no computador do usuário: baixa um app empacotado. Ele não tenta elevar privilégios nem desativar antivírus. O download exige conexão e URL válida. Para produção, assine os executáveis e publique hashes/releases verificáveis.

## Árvore do projeto

```text
PhoneHub/
├── main.py
├── pyproject.toml
├── requirements.txt
├── README.md
├── src/phonehub/
│   ├── app.py                 # Interface Qt e fluxo de inicialização
│   ├── config.py              # Preferências do usuário
│   └── services/
│       ├── android.py         # ADB e lançamento do scrcpy
│       ├── commands.py       # Execução segura de ferramentas externas
│       └── ios.py             # Identificação iOS via libimobiledevice
├── installer/
│   ├── setup_bootstrapper.py  # Downloader/instalador Windows
│   └── release_url.txt       # URL direta do executável publicado
└── scripts/
    ├── run-linux.sh
    ├── build-windows.bat
    └── build-setup.bat
```

## Segurança e limitações

- Nunca exponha ADB diretamente à internet.
- O setup baixa o executável de uma URL configurada pelo desenvolvedor. Use HTTPS, publique checksums e mantenha o link sob seu controle.
- A seleção de GPU não substitui drivers nem transforma GPU integrada em dedicada.
- O vídeo está em janela externa nesta etapa; incorporação de vídeo, mapeamento de teclas/touches e webcam virtual são etapas futuras.
